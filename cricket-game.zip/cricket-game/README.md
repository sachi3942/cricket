# Power Cricket 3D 🏏

Three.js වලින් හදපු Full-3D cricket game එකක්. Capacitor use කරලා Android app එකක් විදිහට wrap කරලා තියෙනවා, GitHub Actions වලින් APK/AAB එක automatic build වෙනවා.

## Features
- Full 3D stadium, pitch, bowler/batsman, ball physics-lite trajectory
- 1 Player vs CPU / 2 Player (same device) modes
- Timing-based batting, meter-based bowling (line & length)
- Two innings, target chase, win/lose logic
- 1 / 2 / 5 over match lengths

---

## 1. GitHub එකට දාගන්නා විදිය

```bash
cd cricket-game
git init
git add .
git commit -m "Power Cricket 3D - initial version"
git branch -M main
git remote add origin https://github.com/<ඔයාගේ-username>/power-cricket-3d.git
git push -u origin main
```

Push කරාට පස්සේ GitHub repo එකේ **Actions** tab එකට යන්න — build එක automatic run වෙනවා (`.github/workflows/build-apk.yml`).

## 2. Test APK එක ගන්නා විදිය (Play Store එකට කලින් test කරන්න)

1. Actions tab → අවසන් run එක click කරන්න
2. පහළින් **Artifacts** section එකේ `app-debug-apk` download කරගන්න
3. ZIP එක extract කරලා `app-debug.apk` ෆෝන් එකට copy කරලා install කරගන්න (Unknown sources allow කරන්න ඕන)

⚠️ **Debug APK එක Play Store එකට upload කරන්න බෑ** — Play Store එකට *signed release* file එකක් ඕන (පහළ පියවර බලන්න).

## 3. Play Store එකට Signed AAB එකක් හදාගන්නා විදිය

### A. Keystore එකක් හදාගන්න (එකම වතාවක් විතරයි)

Terminal එකේ (Java install කරලා තියෙනවා නම්):

```bash
keytool -genkey -v -keystore release.keystore -alias powercricket \
  -keyalg RSA -keysize 2048 -validity 10000
```

මේකෙන් password දෙකක් අහයි (keystore password, key password) — ඒවා memorize කරගන්න, **අහිමි උනොත් app එක update කරන්න බෑ**.

### B. GitHub Secrets 4ක් දාන්න

Repo → **Settings → Secrets and variables → Actions → New repository secret**:

| Secret name | Value |
|---|---|
| `KEYSTORE_BASE64` | `base64 -i release.keystore \| pbcopy` (Mac) හෝ `base64 release.keystore` (Linux/WSL) output එක |
| `KEYSTORE_PASSWORD` | keystore password එක |
| `KEY_ALIAS` | `powercricket` |
| `KEY_PASSWORD` | key password එක |

Secrets 4ම දාපු ගමන් next push එකේදී workflow එක automatic ව signed `app-release.aab` එක build කරලා Artifacts වලට දානවා.

### C. Play Console එකට Upload කරන විදිය

1. [Google Play Console](https://play.google.com/console) → Create app
2. App details, screenshots, privacy policy, content rating fill කරන්න (Play Store එකට mandatory)
3. **Production → Create release** → `app-release.aab` upload කරන්න
4. Review කරලා submit කරන්න (Google review එකට දවස් 1-7ක් යනවා)

---

## Local development (optional)

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android   # Android Studio එකෙන් run/debug කරන්න
```

## Game එක වැඩිදියුණු කරගන්න

- `www/js/game.js` — game logic සහ 3D scene (Three.js)
- `www/style.css` — UI styling
- `www/index.html` — menus & screens

Difficulty, over count options, colors වගේ දේවල් මේ files වල පහසුවෙන් වෙනස් කරගන්න පුළුවන්.
