/* ===================== POWER CRICKET 3D ===================== */

let scene, camera, renderer, ball, bowlerMesh, batsmanMesh, stumpsFar, stumpsNear;
let animId = null;

const state = {
  mode: 'cpu',        // 'cpu' | '2p'
  totalOvers: 2,
  innings: 1,
  battingSide: 0,     // 0 = Player1/Human first-batting side, 1 = other side
  score: [0, 0],
  wickets: [0, 0],
  balls: [0, 0],      // legal balls bowled this innings
  target: null,
  maxWickets: 10,
  phase: 'idle',      // idle | meter | runup | flight | result
  meterVal: 50,
  meterDir: 1,
  meterRunning: false,
  ballStartTime: 0,
  flightDuration: 0,
  hitTime: 0,
  hitWindowHalf: 0,
  swung: false,
  cpuSwingHandle: null,
  bx: 0
};

/* ---------- names ---------- */
function sideName(i){
  if(state.mode === '2p') return i === 0 ? 'Player 1' : 'Player 2';
  return i === 0 ? 'Player 1' : 'CPU';
}
function battingIsHuman(){
  if(state.mode === '2p') return true;
  return state.battingSide === 0;
}
function bowlingIsHuman(){
  if(state.mode === '2p') return true;
  return state.battingSide === 1; // CPU batting => human bowls
}

/* ===================== THREE.JS SCENE ===================== */
function initScene(){
  const canvas = document.getElementById('game-canvas');
  renderer = new THREE.WebGLRenderer({ canvas, antialias:true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x9fd8ff);
  scene.fog = new THREE.Fog(0x9fd8ff, 40, 90);

  camera = new THREE.PerspectiveCamera(62, window.innerWidth/window.innerHeight, 0.1, 200);
  camera.position.set(0, 1.7, 11.5);
  camera.lookAt(0, 1.2, -10);

  // lights
  scene.add(new THREE.HemisphereLight(0xffffff, 0x3a5a3a, 0.9));
  const sun = new THREE.DirectionalLight(0xffffff, 0.9);
  sun.position.set(10, 20, 10);
  scene.add(sun);

  // outfield
  const field = new THREE.Mesh(
    new THREE.CircleGeometry(40, 48),
    new THREE.MeshLambertMaterial({ color: 0x2e7d4f })
  );
  field.rotation.x = -Math.PI/2;
  scene.add(field);

  // boundary rope
  const rope = new THREE.Mesh(
    new THREE.RingGeometry(39.4, 40, 64),
    new THREE.MeshBasicMaterial({ color: 0xffffff })
  );
  rope.rotation.x = -Math.PI/2;
  rope.position.y = 0.01;
  scene.add(rope);

  // pitch strip
  const pitch = new THREE.Mesh(
    new THREE.PlaneGeometry(3, 22),
    new THREE.MeshLambertMaterial({ color: 0xcfb27a })
  );
  pitch.rotation.x = -Math.PI/2;
  pitch.position.set(0, 0.02, -1);
  scene.add(pitch);

  // creases
  addCrease(0, -10);
  addCrease(0, 9);

  // stumps
  stumpsFar = makeStumps();
  stumpsFar.position.set(0, 0, -10);
  scene.add(stumpsFar);

  stumpsNear = makeStumps();
  stumpsNear.position.set(0, 0, 9);
  scene.add(stumpsNear);

  // bowler figure
  bowlerMesh = makeFigure(0x2255aa);
  bowlerMesh.position.set(0, 0, -9);
  scene.add(bowlerMesh);

  // batsman figure
  batsmanMesh = makeFigure(0xcc3333);
  batsmanMesh.position.set(0.6, 0, 8.2);
  scene.add(batsmanMesh);

  // ball
  ball = new THREE.Mesh(
    new THREE.SphereGeometry(0.12, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0xb23a2e, roughness: 0.4 })
  );
  ball.position.set(0, 1.8, -9);
  scene.add(ball);

  // simple stadium ring stands
  const standGeo = new THREE.CylinderGeometry(46, 46, 4, 48, 1, true);
  const standMat = new THREE.MeshLambertMaterial({ color: 0x555a66, side: THREE.BackSide });
  const stands = new THREE.Mesh(standGeo, standMat);
  stands.position.y = 2;
  scene.add(stands);

  window.addEventListener('resize', onResize);
  animate();
}

function addCrease(x, z){
  const line = new THREE.Mesh(
    new THREE.PlaneGeometry(2.6, 0.08),
    new THREE.MeshBasicMaterial({ color: 0xffffff })
  );
  line.rotation.x = -Math.PI/2;
  line.position.set(x, 0.03, z);
  scene.add(line);
}

function makeStumps(){
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color: 0xe8d9a0 });
  for(let i=-1;i<=1;i++){
    const stump = new THREE.Mesh(new THREE.CylinderGeometry(0.035,0.035,0.71,8), mat);
    stump.position.set(i*0.14, 0.355, 0);
    g.add(stump);
  }
  const bail = new THREE.Mesh(new THREE.BoxGeometry(0.32,0.03,0.03), mat);
  bail.position.set(-0.07, 0.72, 0);
  g.add(bail);
  const bail2 = bail.clone(); bail2.position.x = 0.07;
  g.add(bail2);
  return g;
}

function makeFigure(color){
  const g = new THREE.Group();
  const body = new THREE.Mesh(new THREE.CapsuleGeometry ? new THREE.CapsuleGeometry(0.28,0.9,4,8) : new THREE.CylinderGeometry(0.28,0.28,1.3,8),
    new THREE.MeshLambertMaterial({ color }));
  body.position.y = 1.0;
  g.add(body);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.22,12,12), new THREE.MeshLambertMaterial({ color: 0xe0b088 }));
  head.position.y = 1.75;
  g.add(head);
  return g;
}

function onResize(){
  camera.aspect = window.innerWidth/window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate(t){
  animId = requestAnimationFrame(animate);
  updateBallFlight(t || 0);
  renderer.render(scene, camera);
}

/* ===================== METER (BOWLING QUALITY) ===================== */
function meterTick(){
  if(!state.meterRunning) return;
  state.meterVal += state.meterDir * 2.6;
  if(state.meterVal >= 100){ state.meterVal = 100; state.meterDir = -1; }
  if(state.meterVal <= 0){ state.meterVal = 0; state.meterDir = 1; }
  document.getElementById('pitch-meter-fill').style.width = state.meterVal + '%';
  requestAnimationFrame(meterTick);
}

/* ===================== BALL FLOW ===================== */
function startBallSequence(){
  const humanBowls = bowlingIsHuman();

  if(humanBowls && state.phase === 'idle'){
    // start meter, wait for second press
    state.phase = 'meter';
    state.meterRunning = true;
    state.meterVal = 50; state.meterDir = 1;
    document.getElementById('pitch-meter-wrap').classList.remove('hidden');
    document.getElementById('bowl-btn').textContent = 'RELEASE!';
    meterTick();
    return;
  }
  if(humanBowls && state.phase === 'meter'){
    state.meterRunning = false;
    document.getElementById('pitch-meter-wrap').classList.add('hidden');
    launchBall(state.meterVal);
    return;
  }
  if(!humanBowls){
    // CPU bowls with randomized quality (slight ramp with overs)
    const oversDone = state.balls[state.battingSide] / 6;
    const bias = Math.min(20, oversDone * 4);
    let q = 45 + bias + (Math.random()*40 - 20);
    q = Math.max(5, Math.min(95, q));
    launchBall(q);
  }
}

function launchBall(quality){
  state.phase = 'flight';
  document.getElementById('bowl-btn').classList.add('hidden');

  const humanBats = battingIsHuman();
  document.getElementById('swing-btn').classList.toggle('hidden', !humanBats);
  document.getElementById('bowl-btn').textContent = 'BOWL';

  // line variance
  state.bx = (Math.random()*0.7 - 0.35) + (50-quality)/50*0.4*(Math.random()>0.5?1:-1);

  const speed = 0.9 + quality/100*0.5;          // affects duration
  state.flightDuration = 1500 / speed;           // ms
  state.hitWindowHalf = 220 - quality*1.5;       // ms, better ball = tighter window
  state.hitWindowHalf = Math.max(55, state.hitWindowHalf);
  state.ballStartTime = performance.now();
  state.hitTime = state.ballStartTime + state.flightDuration * 0.86;
  state.swung = false;
  state.currentQuality = quality;

  ball.position.set(0, 1.75, -9);

  if(!humanBats){
    scheduleCpuSwing();
  }
}

function updateBallFlight(now){
  if(state.phase !== 'flight') return;
  const elapsed = now - state.ballStartTime;
  const p = Math.min(1, elapsed / state.flightDuration);

  const startZ = -9, endZ = 8.0;
  const z = startZ + (endZ-startZ)*p;
  const x = state.bx * p;
  const arcHeight = Math.sin(Math.min(p,0.55)/0.55 * Math.PI) * 0.9 + (p>0.55 ? Math.sin((p-0.55)/0.45*Math.PI)*0.55 : 0);
  const y = 1.75 - p*1.35 + arcHeight;

  ball.position.set(x, Math.max(0.12,y), z);

  if(p >= 1 && state.phase === 'flight'){
    if(!state.swung) resolveDelivery(false, 0);
  }
}

function scheduleCpuSwing(){
  const skill = 0.62 + Math.random()*0.15;
  const qualityPenalty = (state.currentQuality/100) * 0.32;
  const effectiveSkill = Math.max(0.15, skill - qualityPenalty);
  const errorSpread = (1-effectiveSkill) * state.hitWindowHalf * 2.4;
  const error = (Math.random()*2-1) * errorSpread;
  const swingAt = state.hitTime + error;
  const delay = Math.max(50, swingAt - performance.now());
  state.cpuSwingHandle = setTimeout(()=>{ performSwing(); }, delay);
}

function performSwing(){
  if(state.phase !== 'flight' || state.swung) return;
  state.swung = true;
  const now = performance.now();
  const diff = now - state.hitTime;
  resolveDelivery(true, diff);
}

function resolveDelivery(connected, timeDiff){
  state.phase = 'result';
  if(state.cpuSwingHandle){ clearTimeout(state.cpuSwingHandle); state.cpuSwingHandle=null; }
  document.getElementById('swing-btn').classList.add('hidden');

  const withinWindow = connected && Math.abs(timeDiff) <= state.hitWindowHalf;
  let outcome, runs = 0;

  if(!withinWindow){
    const bowledChance = 0.30 + (state.currentQuality/100)*0.4;
    if(Math.random() < bowledChance){ outcome = 'WICKET'; }
    else { outcome = 'DOT'; }
  } else {
    const accuracy = 1 - Math.abs(timeDiff)/state.hitWindowHalf; // 0..1
    const luck = (Math.random()*0.3 - 0.15);
    const roll = accuracy + luck;
    let catchChance = 0;

    if(roll > 0.82){ runs = 6; outcome = 'SIX'; catchChance = (1-accuracy)*0.38; }
    else if(roll > 0.58){ runs = 4; outcome = 'FOUR'; catchChance = (1-accuracy)*0.22; }
    else if(roll > 0.34){ runs = (Math.random()<0.5?2:3); outcome = runs+' RUNS'; catchChance = (1-accuracy)*0.12; }
    else if(roll > 0.08){ runs = 1; outcome = '1 RUN'; catchChance = (1-accuracy)*0.05; }
    else { runs = 0; outcome = 'DOT'; }

    if(catchChance > 0 && Math.random() < catchChance){
      outcome = 'OUT (CAUGHT)'; runs = 0;
    }
  }

  applyOutcome(outcome, runs);
}

function applyOutcome(outcome, runs){
  const side = state.battingSide;
  state.score[side] += runs;
  state.balls[side] += 1;
  if(outcome.startsWith('WICKET') || outcome.startsWith('OUT')){
    state.wickets[side] += 1;
  }
  showToast(outcome === 'DOT' ? 'DOT BALL' : outcome, runs>=4 ? 'big' : '');
  updateScoreboard();

  setTimeout(()=>{
    checkInningsEnd();
  }, 1300);
}

function showToast(text, cls){
  const el = document.getElementById('result-toast');
  el.textContent = text;
  el.className = cls;
  el.classList.remove('hidden');
  void el.offsetWidth;
  el.style.animation = 'none';
  void el.offsetWidth;
  el.style.animation = '';
  setTimeout(()=> el.classList.add('hidden'), 1100);
}

function updateScoreboard(){
  const side = state.battingSide;
  document.getElementById('score-runs').textContent = state.score[side];
  document.getElementById('score-wkts').textContent = state.wickets[side];
  const overs = Math.floor(state.balls[side]/6) + '.' + (state.balls[side]%6);
  document.getElementById('score-overs').textContent = overs;
  document.getElementById('target-text').textContent = state.target ? ('· Target ' + state.target) : '';
  document.getElementById('turn-label').textContent = sideName(side) + ' Batting';
}

function checkInningsEnd(){
  const side = state.battingSide;
  const oversLimit = state.totalOvers * 6;
  const inningsOver = state.balls[side] >= oversLimit || state.wickets[side] >= state.maxWickets;
  const chaseWon = state.target !== null && state.score[side] >= state.target;

  if(chaseWon){ endMatch(); return; }

  if(inningsOver){
    if(state.innings === 1){
      state.innings = 2;
      state.target = state.score[side] + 1;
      state.battingSide = 1 - side;
      showInfoScreen('Innings 2',
        sideName(state.battingSide) + ' needs ' + state.target + ' runs to win from ' + state.totalOvers + ' overs.');
    } else {
      endMatch();
    }
    return;
  }
  resetForNextBall();
}

function resetForNextBall(){
  state.phase = 'idle';
  document.getElementById('bowl-btn').classList.remove('hidden');
  document.getElementById('bowl-btn').textContent = bowlingIsHuman() ? 'BOWL' : 'READY';
  document.getElementById('swing-btn').classList.add('hidden');
}

function endMatch(){
  const s0 = state.score[0], s1 = state.score[1];
  let text;
  if(state.mode === 'cpu'){
    if(s0 > s1) text = 'You won by ' + (s0-s1) + ' runs! 🏆';
    else if(s1 > s0) text = 'CPU won. Better luck next time.';
    else text = "It's a tie!";
  } else {
    if(s0 > s1) text = 'Player 1 wins by ' + (s0-s1) + ' runs! 🏆';
    else if(s1 > s0) text = 'Player 2 wins by ' + (s1-s0) + ' runs! 🏆';
    else text = "It's a tie!";
  }
  document.getElementById('over-title').textContent = 'MATCH OVER';
  document.getElementById('over-text').innerHTML =
    sideName(0)+': '+s0+'/'+state.wickets[0]+'<br>'+sideName(1)+': '+s1+'/'+state.wickets[1]+'<br><br>'+text;
  showScreen('over-screen');
}

/* ===================== SCREEN FLOW ===================== */
function showScreen(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}

function showInfoScreen(title, text){
  document.getElementById('info-title').textContent = title;
  document.getElementById('info-text').textContent = text;
  showScreen('info-screen');
}

function startMatch(){
  state.innings = 1;
  state.battingSide = 0;
  state.score = [0,0];
  state.wickets = [0,0];
  state.balls = [0,0];
  state.target = null;
  showInfoScreen('Innings 1', sideName(0) + ' is batting first. ' + sideName(1) + (state.mode==='cpu'?' (CPU)':'') + ' will bowl.');
}

function beginPlay(){
  showScreen('game-screen');
  if(!scene) initScene();
  updateScoreboard();
  resetForNextBall();
}

/* ===================== UI WIRING ===================== */
document.querySelectorAll('.opt-btn[data-mode]').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    document.querySelectorAll('.opt-btn[data-mode]').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    state.mode = btn.dataset.mode;
  });
});
document.querySelectorAll('.opt-btn[data-overs]').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    document.querySelectorAll('.opt-btn[data-overs]').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    state.totalOvers = parseInt(btn.dataset.overs, 10);
  });
});

document.getElementById('start-btn').addEventListener('click', startMatch);
document.getElementById('info-continue').addEventListener('click', beginPlay);
document.getElementById('replay-btn').addEventListener('click', ()=> showScreen('menu-screen'));
document.getElementById('bowl-btn').addEventListener('click', startBallSequence);
document.getElementById('swing-btn').addEventListener('click', performSwing);

// keyboard support (desktop testing)
window.addEventListener('keydown', (e)=>{
  if(e.code === 'Space'){
    e.preventDefault();
    if(!document.getElementById('bowl-btn').classList.contains('hidden')) startBallSequence();
    else if(!document.getElementById('swing-btn').classList.contains('hidden')) performSwing();
  }
});
